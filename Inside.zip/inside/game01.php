<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="Picture">
      <label>Foto do game aqui</label><!--Puxar a foto do jogo selecionado-->
    </div>
    <div class="information">
      <h3>JiMMY JiMMY</h3>
      <label>Jogo de ação agilidade e muita diversão!</label><br>
      <label>Jogue com jimmy e sua turma neste incrivel triple a</label><br>
      <label>Desenvolvido por: ASPAS GAMES</label><br>
      <label>Genero:Ação, Aventura.</label>
    </div>
    <div class="user-comment">
      <label class="star"><?php echo "3 estrelas"; ?></label><!-- puxar informções de estrelas que o jogo foi avaliado no banco -->
      <label class="comment"><?php echo "adorei o jogo.";  ?></label><!--Puxar o comentario do usuario com seu nome -->
    </div>
    <div>
      <a href="#"><button type="button" name="jogar">Jogar</button></a>
    </div>
  </body>
</html>
