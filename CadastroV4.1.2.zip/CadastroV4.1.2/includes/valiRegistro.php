<?php
session_start();
$nick = isset($_POST["nick"])?($_POST["nick"]):"";
$senha = MD5(isset($_POST["senha"])?($_POST["senha"]):"");
$email = isset($_POST["email"])?($_POST["email"]):"";

include('conexao.php');

$query_select = mysqli_query($conexao,"SELECT * FROM usuario WHERE nick = '$nick' OR email='$email'");
$array = mysqli_fetch_assoc($query_select);

if($nick == "" || $nick == null){
  header('Location: ../cadastro/cadastro.php?erro=701');
}
elseif($array['nick'] == $nick){
  header('Location: ../cadastro/cadastro.php?erro=702');
}
elseif ($email == "" || $email == null){
  header('Location: ../cadastro/cadastro.php?erro=703');
}
elseif($array['email'] == $email){
  header('Location: ../cadastro/cadastro.php?erro=704');
}
else{
  $query = mysqli_query($conexao, "INSERT INTO usuario VALUES(DEFAULT,'$nick', '$email','$senha', null, null, null)") or die(mysqli_error($conexao));

  header('Location: ../cadastro/cadastro.php?sucesso=1');
}
?>
