<?php
include '../../assets/includes/connect.php';
if (isset($_POST['title'])){
  $title = $_POST['title'];


  $query = sprintf("SELECT titulo FROM genero WHERE titulo = '$title';");
  $dados = mysqli_query($conexao, $query) or die(mysql_error());
  $linha = mysqli_fetch_assoc($dados);

  if (empty($linha)) {
    $query = sprintf("INSERT INTO genero(idgenero,titulo) VALUES (DEFAULT,'$title')");
    $dados = mysqli_query($conexao, $query) or die(mysql_error());

    header('Location: ../../index.php?page=genrereg&sucesso=1');
  } else {
    header('Location: ../../index.php?page=genrereg&erro=702');
  }

} else {
  header('Location: ../../index.php?page=genrereg&erro=1');
}
