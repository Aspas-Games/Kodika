<?php
session_start();
$nick = isset($_POST["nick"])?($_POST["nick"]):"";
$senha = MD5(isset($_POST["senha"])?($_POST["senha"]):"");
$email = isset($_POST["email"])?($_POST["email"]):"";

include('conexao.php');

$query_select = mysqli_query($conexao,"SELECT * FROM usuario WHERE nick = '$nick' OR email='$email'");
$array = mysqli_fetch_assoc($query_select);

if($nick == "" || $nick == null){
  echo"<script language='javascript' type='text/javascript'>
  alert('O campo usuario deve ser preenchido'); window.location.href='../cadastro/cadastro.php';</script>";

}
elseif($array['nick'] == $nick){

  echo"<script language='javascript' type='text/javascript'>
  alert('O usuário cadastrado já existe!!'); window.location.href='../cadastro/cadastro.php';</script>";


}
elseif($array['email'] == $email){

  echo"<script language='javascript' type='text/javascript'>
  alert('O email cadastrado já existe!!'); window.location.href='../cadastro/cadastro.php';</script>";


}
else{
  $query = "INSERT INTO usuario VALUES(DEFAULT,'$nick', '$email','$senha', null, null, null)";
  $insert = mysqli_query($conexao, $query);

  if($insert){
    echo"<script language='javascript' type='text/javascript'>
    alert('O seu cadastro foi efetuado com sucesso!!');window.location.
    href='../login/login.php'</script>";
  }else{
    echo"<script language='javascript' type='text/javascript'>
    alert('Não foi possível efetuar esse cadastro!!'); window.location.href='../cadastro/cadastro.php'</script>";
  }
}
?>
