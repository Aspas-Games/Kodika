<footer>
  <!-- <div class="container">
    <hr>
    <h6 class="text-center">© 2019 Aspas Games. Todos os direitos reservados.</h6>
  </div> -->
</footer>
</body>
</html>
