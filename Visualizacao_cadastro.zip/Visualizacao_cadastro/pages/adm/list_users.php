<main>
  <script>
  <?php include 'media/js/formatTable.js' ?>
  formatTable("#user-list");
  </script>
  <div class="container">
    <div class="container wrap-gamelist">
      <div class="row wrap-gamelist-title">
        <h2 class="d-flex justify-content-start">Usuários Cadastrados</h2>
      </div>
    </div>
    <table id="users-list">
      <thead>
        <tr>
          <th>Código usuário</th>
          <th>Nick</th>
          <th>E-mail</th>
          <th>Nome da fase</th>
          <th>Máximo de pontos</th>
          <th>Código da fase</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include 'assets/includes/connect.php';
        $query = sprintf("SELECT * FROM usuario");
        $dados = mysqli_query($conexao, $query) or die(mysql_error());
        $linha = mysqli_fetch_assoc($dados);
        $total = mysqli_num_rows($dados);
        if($total > 0) {
          do {
            ?>
            <tr>
              <td><?php echo ($linha['idusuario']);?></td>
              <td><?php echo ($linha['nick']);?></td>
              <td><?php echo $linha['email'];?></td>
              <td><?php echo ($linha['nome_fase']);?></td>
              <td><?php echo ($linha['max_ptos']);?></td>
              <td><?php echo ($linha['idFase']);?></td>
                <a href="?pagina=editarUsuario&id=<?php echo ($linha['idusuario']);?>&nick=<?php echo ($linha['nick']);?>&email=<?php echo ($linha['email']);?>&senha=<?php echo ($linha['senha']);?>&nomedafase=<?php echo ($linha['nome_fase']); ?>&máximodepontos=<?php echo ($linha['max_ptos']); ?>&idfase=<?php echo ($linha['idFase']); ?>">
                  <button class="btn btn-primary">Editar</button>
                </a>
                <a href="excluir.php?id=<?php echo ($linha['idusuario']);?>">
                  <button class="btn btn-primary">Excluir</button>
                </a>
              </td>
            </tr>
            <?php
          }while($linha = mysqli_fetch_assoc($dados));
        } else {
          ?>
          <tr>
            <td colspan="7">Nenhum usuário cadastrado.</td>
            <td style="display: none;"></td>
            <td style="display: none;"></td>
            <td style="display: none;"></td>
            <td style="display: none;"></td>
            <td style="display: none;"></td>
            <td style="display: none;"></td>
          </tr>
          <?php
        }
        mysqli_free_result($dados);
        ?>
      </tbody>
    </table>
  </div>
</main>
