function formatTable(table_id) {
  $(document).ready( function () {
    $(table_id).DataTable();
  } );
}
