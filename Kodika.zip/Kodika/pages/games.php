<?php
include 'assets/includes/user_validation.php';
?>
<main>
  <div class="container container-kodika">
    <div class="row">
      <h2 class="text-center subtitulo-kodika col">Meus Jogos:</h2>
    </div>
    <div class="row games-row">
      <?php include 'pages/form/games.php'; ?>
    </div>
  </div>
</main>
