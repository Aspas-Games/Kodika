<?php
include 'assets/includes/user_validation.php';
?>
<main>
  <div class="container container-kodika">
    <h2 class="text-center subtitulo-kodika">Aspas Games - A história não contada</h2>
    <hr class="divider-home">
    <img src="media/img/aspas.jpg" class="image-home">
  </div>
</main>
