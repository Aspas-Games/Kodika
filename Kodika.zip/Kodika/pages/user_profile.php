<?php

if( isset($_GET['nick']) ) {
  $idusuario  = (int)$_GET['nick'];
  $usuario = null;

  // faria aqui o: SELECT * FROM usuarios WHERE id = $usuario_id

  $connect = mysqli_connect ('localhost', 'root', '', 'jimmyjimmy');
  $sel_user = "SELET * FROM usuario where id = '$idusuario'";
  $run_user = mysqli_query ($connect, $sel_user);
  $usuario = mysqli_fetch_array($run_user, MYSQLI_ASSOC);

  if($row == $usuario)
  die('Usuario nao encontrado');
}
else
die('Usuario nao encontrado');

?>

<h2>Perfil de '<?php echo $usuario['nome'] ?>'</h2>

<p>email <?php echo $usuario['email'] ?> anos de idade.</p>
