<?php
session_start();
if (isset($_SESSION['login'])) {
  session_unset(['login']);
  header('Location: ../../index.php');

}
